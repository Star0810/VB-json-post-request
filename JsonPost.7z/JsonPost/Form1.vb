﻿Imports Newtonsoft.Json
Imports System.Net
Imports System.Text
Imports System.IO
Imports System.Net.WebRequestMethods
Imports System.Windows
Imports System.Windows.Forms.DataFormats
Imports Microsoft.SqlServer
Imports Newtonsoft.Json.Linq
Imports System.Reflection.Emit
Imports System.Transactions

Public Class JsonPost

    Private urlToPost As String = ""

    Dim dictData As New Dictionary(Of String, Object)
    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        'dictData.Add("", "")
        'postData(dictData)
        'ostData("qw", "qw")
        'dictData.Add("test_key", "test_value")
        'jsonPost.postData(dictData)
    End Sub

    Private Async Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim json As String = IO.File.ReadAllText("fra241.json")
        Dim o As JObject = JObject.Parse(json)
        Diagnostics.Debug.WriteLine(o)

        Dim content = Newtonsoft.Json.JsonConvert.SerializeObject(o)
        Dim buffer = System.Text.Encoding.UTF8.GetBytes(content)
        Dim bytes = New Net.Http.ByteArrayContent(buffer)
        bytes.Headers.ContentType = New Net.Http.Headers.MediaTypeHeaderValue("application/json")
        'bytes.Headers.Add("Accept", "application/json")
        bytes.Headers.Add("X-Qbikode-ClientApiKey", "IyaegCNSBIHlCBreDERfwNyR9RQOZc0tvPF7w3tbedneT4ViqxZH4bKQ1ksE8ZBu46OVn8Um7PUsNYeA4VdRGIXlga2hh97QDXQ6")
        Dim responseBody As String = Nothing
        Using client As New System.Net.Http.HttpClient
            Dim response = Await client.PostAsync("https://wstests.kubibai.com/api/invoicing/invoices", bytes)
            responseBody = Await response.Content.ReadAsStringAsync()
        End Using

        Dim data = Newtonsoft.Json.JsonConvert.DeserializeObject(Of JObject)(responseBody)
        Diagnostics.Debug.WriteLine(data)
        Label1.Text = data.ToString()
        'ListView1.Items.Add(data.ToString())
    End Sub
End Class